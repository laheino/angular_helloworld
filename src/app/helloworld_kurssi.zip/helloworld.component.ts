import {Component} from '@angular/core';

@Component({
	selector:'hello-world',
	templateUrl:'./helloworld.component.html'
})
export class HelloWorld {
	message = "Hello World!"
}
